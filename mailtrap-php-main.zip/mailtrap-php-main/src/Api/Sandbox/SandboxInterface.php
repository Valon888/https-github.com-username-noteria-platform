<?php

declare(strict_types=1);

namespace Mailtrap\Api\Sandbox;

interface SandboxInterface
{
}
