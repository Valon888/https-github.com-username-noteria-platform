<?php

declare(strict_types=1);

namespace Mailtrap\Api\Sending;

interface SendingInterface
{
}
