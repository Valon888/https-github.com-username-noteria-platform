<?php

declare(strict_types=1);

namespace Mailtrap\Api\General;

interface GeneralInterface
{
}
