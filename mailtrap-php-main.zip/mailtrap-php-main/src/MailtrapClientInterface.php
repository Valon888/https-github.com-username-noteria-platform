<?php

declare(strict_types=1);

namespace Mailtrap;

interface MailtrapClientInterface
{
    public const API_MAPPING = [];
}
