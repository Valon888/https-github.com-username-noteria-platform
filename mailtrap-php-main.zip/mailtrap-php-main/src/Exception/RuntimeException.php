<?php

declare(strict_types=1);

namespace Mailtrap\Exception;

/**
 * Class RuntimeException
 */
class RuntimeException extends \RuntimeException implements MailtrapExceptionInterface
{
}
