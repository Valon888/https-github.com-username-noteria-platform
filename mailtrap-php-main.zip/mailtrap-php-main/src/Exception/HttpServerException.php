<?php

declare(strict_types=1);

namespace Mailtrap\Exception;

/**
 * Class HttpServerException
 */
class HttpServerException extends HttpException
{
}
