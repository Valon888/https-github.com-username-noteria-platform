<?php

declare(strict_types=1);

namespace Mailtrap\Exception;

/**
 * Class LogicException
 */
class LogicException extends \LogicException implements MailtrapExceptionInterface
{
}
