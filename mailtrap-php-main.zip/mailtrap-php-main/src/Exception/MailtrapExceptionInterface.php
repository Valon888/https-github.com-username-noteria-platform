<?php

declare(strict_types=1);

namespace Mailtrap\Exception;

/**
 * All Mailtrap exception implements this exception.
 *
 * Class MailtrapExceptionInterface
 */
interface MailtrapExceptionInterface extends \Throwable
{
}
