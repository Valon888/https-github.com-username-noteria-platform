<?php

declare(strict_types=1);

namespace Mailtrap\Exception;

/**
 * Class HttpException
 */
class HttpException extends RuntimeException
{
}
